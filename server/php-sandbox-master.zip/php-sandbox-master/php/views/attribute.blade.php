<div class="box box-solid box-default" style="margin:20px;width: auto;min-width:200px;float: left;height: auto;min-height:85px;border:2px solid #d2d6de">
    <div class="box-header">
        <h3 class="box-title">{{__($title)}}</h3>
    </div>
    <div class="box-body" style="height: auto;">
        <span style="height: auto" id="{{$id}}" class="{{$class}}"></span>
    </div>
</div>