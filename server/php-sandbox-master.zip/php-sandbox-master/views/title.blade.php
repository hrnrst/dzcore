@section('content_header')
    <h1>{{ __($title) }}</h1>
@stop