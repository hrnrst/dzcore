(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8702], {
        1325: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.363.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, t(5711).Z)("CirclePlus", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "10",
                    key: "1mglay"
                }],
                ["path", {
                    d: "M8 12h8",
                    key: "1wcyev"
                }],
                ["path", {
                    d: "M12 8v8",
                    key: "napkw2"
                }]
            ])
        },
        9404: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.363.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, t(5711).Z)("Ellipsis", [
                ["circle", {
                    cx: "12",
                    cy: "12",
                    r: "1",
                    key: "41hilf"
                }],
                ["circle", {
                    cx: "19",
                    cy: "12",
                    r: "1",
                    key: "1wjl8i"
                }],
                ["circle", {
                    cx: "5",
                    cy: "12",
                    r: "1",
                    key: "1pcz8c"
                }]
            ])
        },
        2664: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.363.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, t(5711).Z)("Footprints", [
                ["path", {
                    d: "M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z",
                    key: "1dudjm"
                }],
                ["path", {
                    d: "M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z",
                    key: "l2t8xc"
                }],
                ["path", {
                    d: "M16 17h4",
                    key: "1dejxt"
                }],
                ["path", {
                    d: "M4 13h4",
                    key: "1bwh8b"
                }]
            ])
        },
        2448: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.363.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, t(5711).Z)("Pen", [
                ["path", {
                    d: "M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z",
                    key: "5qss01"
                }]
            ])
        },
        3671: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.363.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, t(5711).Z)("Trash", [
                ["path", {
                    d: "M3 6h18",
                    key: "d0wm0j"
                }],
                ["path", {
                    d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",
                    key: "4alrt4"
                }],
                ["path", {
                    d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",
                    key: "v07s0e"
                }]
            ])
        },
        3682: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return r
                }
            });
            /**
             * @license lucide-react v0.363.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let r = (0, t(5711).Z)("UserRound", [
                ["circle", {
                    cx: "12",
                    cy: "8",
                    r: "5",
                    key: "1hypcn"
                }],
                ["path", {
                    d: "M20 21a8 8 0 0 0-16 0",
                    key: "rfgkzh"
                }]
            ])
        },
        7391: function(e, s, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/settings/users", function() {
                return t(7477)
            }])
        },
        2766: function(e, s, t) {
            "use strict";
            t.d(s, {
                NI: function() {
                    return p
                },
                Wi: function() {
                    return u
                },
                l0: function() {
                    return o
                },
                lX: function() {
                    return h
                },
                pf: function() {
                    return j
                },
                xJ: function() {
                    return f
                },
                zG: function() {
                    return g
                }
            });
            var r = t(5893),
                a = t(7294),
                n = t(8426),
                l = t(7536),
                i = t(7327),
                c = t(2297);
            let o = l.RV,
                d = a.createContext({}),
                u = e => {
                    let {
                        ...s
                    } = e;
                    return (0, r.jsx)(d.Provider, {
                        value: {
                            name: s.name
                        },
                        children: (0, r.jsx)(l.Qr, {
                            ...s
                        })
                    })
                },
                m = () => {
                    let e = a.useContext(d),
                        s = a.useContext(x),
                        {
                            getFieldState: t,
                            formState: r
                        } = (0, l.Gc)(),
                        n = t(e.name, r);
                    if (!e) throw Error("useFormField should be used within <FormField>");
                    let {
                        id: i
                    } = s;
                    return {
                        id: i,
                        name: e.name,
                        formItemId: "".concat(i, "-form-item"),
                        formDescriptionId: "".concat(i, "-form-item-description"),
                        formMessageId: "".concat(i, "-form-item-message"),
                        ...n
                    }
                },
                x = a.createContext({}),
                f = a.forwardRef((e, s) => {
                    let {
                        className: t,
                        ...n
                    } = e, l = a.useId();
                    return (0, r.jsx)(x.Provider, {
                        value: {
                            id: l
                        },
                        children: (0, r.jsx)("div", {
                            ref: s,
                            className: (0, i.cn)("space-y-2", t),
                            ...n
                        })
                    })
                });
            f.displayName = "FormItem";
            let h = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e, {
                    error: n,
                    formItemId: l
                } = m();
                return (0, r.jsx)(c._, {
                    ref: s,
                    className: (0, i.cn)(n && "text-destructive", t),
                    htmlFor: l,
                    ...a
                })
            });
            h.displayName = "FormLabel";
            let p = a.forwardRef((e, s) => {
                let {
                    ...t
                } = e, {
                    error: a,
                    formItemId: l,
                    formDescriptionId: i,
                    formMessageId: c
                } = m();
                return (0, r.jsx)(n.g7, {
                    ref: s,
                    id: l,
                    "aria-describedby": a ? "".concat(i, " ").concat(c) : "".concat(i),
                    "aria-invalid": !!a,
                    ...t
                })
            });
            p.displayName = "FormControl";
            let j = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e, {
                    formDescriptionId: n
                } = m();
                return (0, r.jsx)("p", {
                    ref: s,
                    id: n,
                    className: (0, i.cn)("text-sm text-muted-foreground", t),
                    ...a
                })
            });
            j.displayName = "FormDescription";
            let g = a.forwardRef((e, s) => {
                let {
                    className: t,
                    children: a,
                    ...n
                } = e, {
                    error: l,
                    formMessageId: c
                } = m(), o = l ? String(null == l ? void 0 : l.message) : a;
                return o ? (0, r.jsx)("p", {
                    ref: s,
                    id: c,
                    className: (0, i.cn)("text-sm font-medium text-destructive", t),
                    ...n,
                    children: o
                }) : null
            });
            g.displayName = "FormMessage"
        },
        9827: function(e, s, t) {
            "use strict";
            t.d(s, {
                C: function() {
                    return i
                }
            });
            var r = t(5893);
            t(7294);
            var a = t(5139),
                n = t(7327);
            let l = (0, a.j)("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
                variants: {
                    variant: {
                        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
                        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
                        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
                        success: "border-transparent bg-green-500 text-white hover:bg-green-500/80",
                        outline: "text-foreground"
                    }
                },
                defaultVariants: {
                    variant: "default"
                }
            });

            function i(e) {
                let {
                    className: s,
                    variant: t,
                    ...a
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, n.cn)(l({
                        variant: t
                    }), s),
                    ...a
                })
            }
        },
        3749: function(e, s, t) {
            "use strict";
            t.d(s, {
                Ol: function() {
                    return i
                },
                Zb: function() {
                    return l
                },
                aY: function() {
                    return o
                },
                ll: function() {
                    return c
                }
            });
            var r = t(5893),
                a = t(7294),
                n = t(7327);
            let l = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)("div", {
                    ref: s,
                    className: (0, n.cn)("rounded-lg border bg-card text-card-foreground shadow-sm", t),
                    ...a
                })
            });
            l.displayName = "Card";
            let i = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)("div", {
                    ref: s,
                    className: (0, n.cn)("flex flex-col space-y-1.5 p-6", t),
                    ...a
                })
            });
            i.displayName = "CardHeader";
            let c = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)("h3", {
                    ref: s,
                    className: (0, n.cn)("text-lg font-semibold leading-none tracking-tight", t),
                    ...a
                })
            });
            c.displayName = "CardTitle", a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)("p", {
                    ref: s,
                    className: (0, n.cn)("text-sm text-muted-foreground", t),
                    ...a
                })
            }).displayName = "CardDescription";
            let o = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)("div", {
                    ref: s,
                    className: (0, n.cn)("p-6 pt-0", t),
                    ...a
                })
            });
            o.displayName = "CardContent", a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)("div", {
                    ref: s,
                    className: (0, n.cn)(" flex items-center p-6 pt-0", t),
                    ...a
                })
            }).displayName = "CardFooter"
        },
        1648: function(e, s, t) {
            "use strict";
            t.d(s, {
                X: function() {
                    return c
                }
            });
            var r = t(5893),
                a = t(7294),
                n = t(6069),
                l = t(3742),
                i = t(7327);
            let c = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)(n.fC, {
                    ref: s,
                    className: (0, i.cn)("peer size-4 shrink-0 overflow-hidden rounded-full border border-primary ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary/75 data-[state=checked]:text-primary-foreground", t),
                    ...a,
                    children: (0, r.jsx)(n.z$, {
                        className: (0, i.cn)("flex items-center justify-center rounded-full text-current"),
                        children: (0, r.jsx)(l.Z, {
                            className: "size-full"
                        })
                    })
                })
            });
            c.displayName = n.fC.displayName
        },
        2297: function(e, s, t) {
            "use strict";
            t.d(s, {
                _: function() {
                    return o
                }
            });
            var r = t(5893),
                a = t(7294),
                n = t(9102),
                l = t(5139),
                i = t(7327);
            let c = (0, l.j)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),
                o = a.forwardRef((e, s) => {
                    let {
                        className: t,
                        ...a
                    } = e;
                    return (0, r.jsx)(n.f, {
                        ref: s,
                        className: (0, i.cn)(c(), t),
                        ...a
                    })
                });
            o.displayName = n.f.displayName
        },
        986: function(e, s, t) {
            "use strict";
            t.d(s, {
                Z: function() {
                    return l
                }
            });
            var r = t(5893),
                a = t(9008),
                n = t.n(a);

            function l(e) {
                let {
                    title: s,
                    description: t,
                    rightSide: a
                } = e;
                return (0, r.jsxs)("div", {
                    className: "flex-1 flex-col p-8 md:flex",
                    children: [(0, r.jsx)(n(), {
                        children: (0, r.jsx)("title", {
                            children: "".concat(s, " | DZ")
                        })
                    }), (0, r.jsxs)("div", {
                        className: "flex items-center justify-between space-y-2",
                        children: [(0, r.jsxs)("div", {
                            children: [(0, r.jsx)("h2", {
                                className: "text-2xl font-bold tracking-tight",
                                children: s
                            }), (0, r.jsx)("p", {
                                className: "text-muted-foreground",
                                children: t
                            })]
                        }), a && (0, r.jsx)("div", {
                            className: "flex items-center",
                            children: a
                        })]
                    })]
                })
            }
        },
        4210: function(e, s, t) {
            "use strict";
            t.d(s, {
                Ei: function() {
                    return y
                },
                FF: function() {
                    return j
                },
                Tu: function() {
                    return p
                },
                aM: function() {
                    return d
                },
                bC: function() {
                    return g
                },
                sw: function() {
                    return u
                },
                ue: function() {
                    return h
                },
                yo: function() {
                    return o
                }
            });
            var r = t(5893),
                a = t(7294),
                n = t(2854),
                l = t(5139),
                i = t(1352),
                c = t(7327);
            let o = n.fC,
                d = n.xz,
                u = n.x8,
                m = e => {
                    let {
                        className: s,
                        ...t
                    } = e;
                    return (0, r.jsx)(n.h_, {
                        className: (0, c.cn)(s),
                        ...t
                    })
                };
            m.displayName = n.h_.displayName;
            let x = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, c.cn)("fixed inset-0 z-50 bg-background/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", t),
                    ...a,
                    ref: s
                })
            });
            x.displayName = n.aV.displayName;
            let f = (0, l.j)("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-500 overflow-y-auto", {
                    variants: {
                        side: {
                            top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
                            bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
                            left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
                            right: "inset-y-0 right-0 h-full w-3/4  border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
                        }
                    },
                    defaultVariants: {
                        side: "right"
                    }
                }),
                h = a.forwardRef((e, s) => {
                    let {
                        side: t = "right",
                        className: a,
                        children: l,
                        ...o
                    } = e;
                    return (0, r.jsxs)(m, {
                        children: [(0, r.jsx)(x, {}), (0, r.jsxs)(n.VY, {
                            ref: s,
                            className: (0, c.cn)(f({
                                side: t
                            }), a),
                            ...o,
                            children: [l, (0, r.jsxs)(n.x8, {
                                className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
                                children: [(0, r.jsx)(i.Z, {
                                    className: "size-4"
                                }), (0, r.jsx)("span", {
                                    className: "sr-only",
                                    children: "Close"
                                })]
                            })]
                        })]
                    })
                });
            h.displayName = n.VY.displayName;
            let p = e => {
                let {
                    className: s,
                    ...t
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, c.cn)("flex flex-col space-y-2 text-center sm:text-left", s),
                    ...t
                })
            };
            p.displayName = "SheetHeader";
            let j = e => {
                let {
                    className: s,
                    ...t
                } = e;
                return (0, r.jsx)("div", {
                    className: (0, c.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", s),
                    ...t
                })
            };
            j.displayName = "SheetFooter";
            let g = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)(n.Dx, {
                    ref: s,
                    className: (0, c.cn)("text-lg font-semibold text-foreground", t),
                    ...a
                })
            });
            g.displayName = n.Dx.displayName;
            let y = a.forwardRef((e, s) => {
                let {
                    className: t,
                    ...a
                } = e;
                return (0, r.jsx)(n.dk, {
                    ref: s,
                    className: (0, c.cn)("text-sm text-muted-foreground", t),
                    ...a
                })
            });
            y.displayName = n.dk.displayName
        },
        5050: function(e, s, t) {
            "use strict";
            t.d(s, {
                p: function() {
                    return n
                }
            }), t(7294);
            var r = t(7421),
                a = t(4712);

            function n() {
                let {
                    t: e
                } = (0, r.$G)("common");
                return {
                    toast: s => {
                        let {
                            title: t,
                            description: r,
                            variant: n
                        } = s, l = {
                            description: r,
                            duration: 6e3,
                            dismissible: !0
                        }, i = "";
                        switch (t == e("information") ? i = "info" : t == e("success") ? i = "success" : t == e("error") ? i = "error" : t == e("warning") && (i = "warning"), n && (i = n), i) {
                            case "success":
                                return a.A.success(t, l);
                            case "error":
                            case "destructive":
                                return a.A.error(t, l);
                            case "warning":
                                return a.A.warning(t, l);
                            case "info":
                                return a.A.info(t, l);
                            default:
                                return (0, a.A)(t, l)
                        }
                    }
                }
            }
        },
        8946: function(e, s, t) {
            "use strict";
            t.d(s, {
                q: function() {
                    return a
                }
            });
            let r = (0, t(9391).Z)(),
                a = () => r
        },
        7477: function(e, s, t) {
            "use strict";
            t.r(s), t.d(s, {
                default: function() {
                    return H
                }
            });
            var r = t(5893),
                a = t(7294),
                n = t(1163),
                l = t(9774);
            /**
             * @license lucide-react v0.363.0 - ISC
             *
             * This source code is licensed under the ISC license.
             * See the LICENSE file in the root directory of this source tree.
             */
            let i = (0, t(5711).Z)("UserRoundCog", [
                ["path", {
                    d: "M2 21a8 8 0 0 1 10.434-7.62",
                    key: "1yezr2"
                }],
                ["circle", {
                    cx: "10",
                    cy: "8",
                    r: "5",
                    key: "o932ke"
                }],
                ["circle", {
                    cx: "18",
                    cy: "18",
                    r: "3",
                    key: "1xkwt0"
                }],
                ["path", {
                    d: "m19.5 14.3-.4.9",
                    key: "1eb35c"
                }],
                ["path", {
                    d: "m16.9 20.8-.4.9",
                    key: "dfjc4z"
                }],
                ["path", {
                    d: "m21.7 19.5-.9-.4",
                    key: "q4dx6b"
                }],
                ["path", {
                    d: "m15.2 16.9-.9-.4",
                    key: "1r0w5f"
                }],
                ["path", {
                    d: "m21.7 16.5-.9.4",
                    key: "1knoei"
                }],
                ["path", {
                    d: "m15.2 19.1-.9.4",
                    key: "j188fs"
                }],
                ["path", {
                    d: "m19.5 21.7-.4-.9",
                    key: "1tonu5"
                }],
                ["path", {
                    d: "m16.9 15.2-.4-.9",
                    key: "699xu"
                }]
            ]);
            var c = t(3682),
                o = t(3742),
                d = t(1352),
                u = t(2664),
                m = t(7421),
                x = t(7327),
                f = t(8946),
                h = t(9827),
                p = t(7249),
                j = t(5282),
                g = t(2532),
                y = t(7622),
                v = t(986),
                _ = t(8876),
                N = t(6312),
                b = t(1325),
                w = t(7536),
                k = t(1604),
                C = t(4210),
                z = t(2766),
                F = t(5037),
                E = t(2297),
                Z = t(4462),
                R = t(5050);

            function S() {
                let {
                    toast: e
                } = (0, R.p)(), s = (0, f.q)(), {
                    t
                } = (0, m.$G)("settings"), n = k.z.object({
                    name: k.z.string().min(2, {
                        message: t("users.validation.n_min")
                    }).max(50, {
                        message: t("users.validation.n_max")
                    }),
                    username: k.z.string().min(2, {
                        message: t("users.validation.name_min")
                    }).max(50, {
                        message: t("users.validation.name_max")
                    }),
                    email: k.z.string().email({
                        message: t("users.validation.email")
                    }),
                    status: k.z.string(),
                    password: k.z.string().min(8, {
                        message: t("users.validation.password_min")
                    }).max(50, {
                        message: t("users.validation.password_max")
                    }),
                    password_confirmation: k.z.string()
                }).refine(e => e.password === e.password_confirmation, {
                    message: t("users.validation.password_confirmation"),
                    path: ["password_confirmation"]
                }), i = (0, w.cI)({
                    resolver: (0, N.F)(n),
                    defaultValues: {
                        name: "",
                        username: "",
                        email: "",
                        status: "0",
                        password: "",
                        password_confirmation: ""
                    }
                }), [c, o] = (0, a.useState)(!1);
                return (0, r.jsxs)(C.yo, {
                    open: c,
                    onOpenChange: e => o(e),
                    children: [(0, r.jsx)(C.aM, {
                        asChild: !0,
                        children: (0, r.jsxs)(p.z, {
                            variant: "outline",
                            size: "sm",
                            className: "ml-auto h-8 lg:flex",
                            children: [(0, r.jsx)(b.Z, {
                                className: "mr-2 size-4"
                            }), t("users.create.button")]
                        })
                    }), (0, r.jsxs)(C.ue, {
                        side: "right",
                        children: [(0, r.jsxs)(C.Tu, {
                            className: "mb-8",
                            children: [(0, r.jsx)(C.bC, {
                                children: t("users.create.title")
                            }), (0, r.jsx)(C.Ei, {
                                children: t("users.create.description")
                            })]
                        }), (0, r.jsx)(z.l0, {
                            ...i,
                            children: (0, r.jsxs)("form", {
                                onSubmit: i.handleSubmit(r => {
                                    l.dJ.post("/settings/users", r).then(r => {
                                        200 === r.status ? (e({
                                            title: t("success"),
                                            description: t("users.toasts.success_msg")
                                        }), s.emit("REFETCH_USERS"), o(!1), i.reset()) : e({
                                            title: t("error"),
                                            description: t("users.toasts.error_msg"),
                                            variant: "destructive"
                                        })
                                    }).catch(s => {
                                        (0, x.FB)(s, i) || e({
                                            title: t("error"),
                                            description: t("users.toasts.error_msg"),
                                            variant: "destructive"
                                        })
                                    })
                                }),
                                className: "space-y-5",
                                children: [(0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "status",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "status",
                                                children: t("users.create.user_type")
                                            }), (0, r.jsxs)(Z.Ph, {
                                                onValueChange: s.onChange,
                                                defaultValue: s.value,
                                                children: [(0, r.jsx)(Z.i4, {
                                                    children: (0, r.jsx)(Z.ki, {})
                                                }), (0, r.jsxs)(Z.Bw, {
                                                    children: [(0, r.jsx)(Z.Ql, {
                                                        value: "0",
                                                        children: t("users.create.user")
                                                    }), (0, r.jsx)(Z.Ql, {
                                                        value: "1",
                                                        children: t("users.create.admin")
                                                    })]
                                                })]
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "name",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "name",
                                                children: t("users.create.name_surname")
                                            }), (0, r.jsx)(F.I, {
                                                id: "name",
                                                placeholder: t("users.create.name_surname_placeholder"),
                                                ...s
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "username",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "username",
                                                children: t("users.create.username")
                                            }), (0, r.jsx)(F.I, {
                                                id: "username",
                                                placeholder: "dzuser",
                                                ...s
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "email",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "email",
                                                children: t("users.create.email")
                                            }), (0, r.jsx)(F.I, {
                                                id: "email",
                                                placeholder: "user@dz.dev",
                                                ...s,
                                                type: "email"
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "password",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "password",
                                                children: t("users.create.password")
                                            }), (0, r.jsx)(F.I, {
                                                id: "password",
                                                ...s,
                                                className: "col-span-3",
                                                type: "password"
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "password_confirmation",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "password_confirmation",
                                                children: t("users.create.password_confirmation")
                                            }), (0, r.jsx)(F.I, {
                                                id: "password_confirmation",
                                                ...s,
                                                className: "col-span-3",
                                                type: "password"
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(C.FF, {
                                    children: (0, r.jsxs)(p.z, {
                                        type: "submit",
                                        children: [(0, r.jsx)(b.Z, {
                                            className: "mr-2 size-4"
                                        }), " ", t("users.create.create")]
                                    })
                                })]
                            })
                        })]
                    })]
                })
            }
            var I = t(2448),
                G = t(3749),
                D = t(1648),
                M = t(1956);

            function T() {
                let {
                    toast: e
                } = (0, R.p)(), s = (0, f.q)(), {
                    t
                } = (0, m.$G)("settings"), n = k.z.object({
                    id: k.z.string(),
                    name: k.z.string().min(2, {
                        message: t("users.validation.n_min")
                    }).max(50, {
                        message: t("users.validation.n_max")
                    }),
                    username: k.z.string().min(2, {
                        message: t("users.validation.name_min")
                    }).max(50, {
                        message: t("users.validation.name_max")
                    }),
                    email: k.z.string().email({
                        message: t("users.validation.email")
                    }),
                    status: k.z.coerce.number(),
                    password: k.z.string().optional(),
                    roles: k.z.array(k.z.string()).optional(),
                    session_time: k.z.coerce.number().min(15).max(999999)
                }), i = (0, w.cI)({
                    resolver: (0, N.F)(n),
                    defaultValues: {
                        id: "",
                        name: "",
                        username: "",
                        email: "",
                        status: 0,
                        password: "",
                        roles: [],
                        session_time: 120
                    }
                }), [c, o] = (0, a.useState)(!1), [d, u] = (0, a.useState)(), [h, j] = (0, a.useState)([]);
                return (0, a.useEffect)(() => (s.on("EDIT_USER", e => {
                    u(e), o(!0), i.reset({
                        id: e.id,
                        name: e.name,
                        username: e.username,
                        email: e.email,
                        status: e.status,
                        password: "",
                        roles: [],
                        session_time: e.session_time
                    }), l.dJ.get("/settings/users/".concat(e.id, "/roles")).then(s => {
                        j(s.data), i.reset({
                            id: e.id,
                            name: e.name,
                            username: e.username,
                            email: e.email,
                            status: e.status,
                            password: "",
                            roles: s.data.filter(e => e.selected).map(e => e.id),
                            session_time: e.session_time
                        })
                    })
                }), () => s.off("EDIT_USER")), []), (0, r.jsx)(C.yo, {
                    open: c,
                    onOpenChange: e => o(e),
                    children: (0, r.jsxs)(C.ue, {
                        side: "right",
                        className: "sm:w-[500px] sm:max-w-full",
                        children: [(0, r.jsxs)(C.Tu, {
                            className: "mb-8",
                            children: [(0, r.jsx)(C.bC, {
                                children: t("users.edit.title")
                            }), (0, r.jsx)(C.Ei, {
                                children: t("users.edit.description")
                            })]
                        }), (0, r.jsx)(z.l0, {
                            ...i,
                            children: (0, r.jsxs)("form", {
                                onSubmit: i.handleSubmit(r => {
                                    l.dJ.patch("/settings/users/".concat(r.id), r).then(r => {
                                        200 === r.status ? (e({
                                            title: t("success"),
                                            description: t("users.toasts.edit_success_msg")
                                        }), s.emit("REFETCH_USERS"), o(!1), i.reset()) : e({
                                            title: t("error"),
                                            description: t("users.toasts.edit_error_msg"),
                                            variant: "destructive"
                                        })
                                    }).catch(s => {
                                        (0, x.FB)(s, i) || e({
                                            title: t("error"),
                                            description: t("users.toasts.edit_error_msg"),
                                            variant: "destructive"
                                        })
                                    })
                                }),
                                className: "space-y-5",
                                children: [(0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "status",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "status",
                                                children: t("users.create.user_type")
                                            }), (0, r.jsxs)(Z.Ph, {
                                                onValueChange: s.onChange,
                                                defaultValue: String(s.value),
                                                children: [(0, r.jsx)(Z.i4, {
                                                    children: (0, r.jsx)(Z.ki, {})
                                                }), (0, r.jsxs)(Z.Bw, {
                                                    children: [(0, r.jsx)(Z.Ql, {
                                                        value: "0",
                                                        children: t("users.create.user")
                                                    }), (0, r.jsx)(Z.Ql, {
                                                        value: "1",
                                                        children: t("users.create.admin")
                                                    })]
                                                })]
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "name",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "name",
                                                children: t("users.create.name_surname")
                                            }), (0, r.jsx)(F.I, {
                                                id: "name",
                                                placeholder: t("users.create.name_surname_placeholder"),
                                                ...s
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "username",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "username",
                                                children: t("users.create.username")
                                            }), (0, r.jsx)(F.I, {
                                                id: "username",
                                                placeholder: "limanuser",
                                                ...s,
                                                disabled: (null == d ? void 0 : d.auth_type) === "ldap"
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "email",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "email",
                                                children: t("users.create.email")
                                            }), (0, r.jsx)(F.I, {
                                                id: "email",
                                                placeholder: "user@dz.dev",
                                                ...s,
                                                type: "email",
                                                disabled: (null == d ? void 0 : d.auth_type) === "ldap"
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "password",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "password",
                                                children: t("users.create.password")
                                            }), (0, r.jsx)(F.I, {
                                                id: "password",
                                                ...s,
                                                className: "col-span-3",
                                                type: "password",
                                                disabled: (null == d ? void 0 : d.auth_type) === "ldap"
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "session_time",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "session_time",
                                                children: t("users.create.session_time")
                                            }), (0, r.jsx)(F.I, {
                                                type: "number",
                                                id: "session_time",
                                                placeholder: t("users.create.session_time_placeholder"),
                                                ...s
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(z.Wi, {
                                    control: i.control,
                                    name: "roles",
                                    render: e => {
                                        let {
                                            field: s
                                        } = e;
                                        return (0, r.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [(0, r.jsx)(E._, {
                                                htmlFor: "roles",
                                                children: t("users.edit.roles")
                                            }), (0, r.jsx)(G.Zb, {
                                                children: (0, r.jsx)("div", {
                                                    className: "p-3",
                                                    children: (0, r.jsx)(M.x, {
                                                        className: "h-24",
                                                        children: (0, r.jsx)("div", {
                                                            className: "flex flex-col gap-2",
                                                            children: h.map(e => (0, r.jsxs)("div", {
                                                                className: "flex items-center gap-2",
                                                                children: [(0, r.jsx)(D.X, {
                                                                    id: e.name,
                                                                    value: e.id,
                                                                    checked: e.selected,
                                                                    onCheckedChange: t => {
                                                                        j(h.map(s => s.id === e.id ? {
                                                                            ...s,
                                                                            selected: t
                                                                        } : s)), s.onChange(h.map(s => s.id === e.id ? {
                                                                            ...s,
                                                                            selected: t
                                                                        } : s).filter(e => e.selected).map(e => e.id))
                                                                    }
                                                                }), (0, r.jsx)(E._, {
                                                                    htmlFor: e.name,
                                                                    children: e.name
                                                                })]
                                                            }, e.id))
                                                        })
                                                    })
                                                })
                                            }), (0, r.jsx)(z.zG, {
                                                className: "mt-1"
                                            })]
                                        })
                                    }
                                }), (0, r.jsx)(C.FF, {
                                    children: (0, r.jsxs)(p.z, {
                                        type: "submit",
                                        children: [(0, r.jsx)(I.Z, {
                                            className: "mr-2 size-4"
                                        }), " ", t("users.edit.submit")]
                                    })
                                })]
                            })
                        })]
                    })
                })
            }
            var V = t(9404),
                L = t(3671),
                P = t(2361),
                O = t(7776),
                W = t(733);

            function q(e) {
                let {
                    row: s
                } = e, t = s.original, [n, l] = (0, a.useState)(!1), i = (0, f.q)(), {
                    t: c
                } = (0, m.$G)("settings");
                return (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsxs)(O.h_, {
                        children: [(0, r.jsx)(O.$F, {
                            asChild: !0,
                            children: (0, r.jsxs)(p.z, {
                                variant: "ghost",
                                className: "flex size-5 p-0 data-[state=open]:bg-muted",
                                children: [(0, r.jsx)(V.Z, {
                                    className: "size-4"
                                }), (0, r.jsx)("span", {
                                    className: "sr-only",
                                    children: "Open menu"
                                })]
                            })
                        }), (0, r.jsxs)(O.AW, {
                            align: "end",
                            className: "w-[160px]",
                            children: [(0, r.jsxs)(O.Xi, {
                                onClick: () => i.emit("EDIT_USER", t),
                                children: [(0, r.jsx)(I.Z, {
                                    className: "mr-2 size-3.5"
                                }), c("roles.actions.edit")]
                            }), (0, r.jsxs)(O.Xi, {
                                onClick: () => i.emit("AUTH_LOG_DIALOG", t.id),
                                children: [(0, r.jsx)(u.Z, {
                                    className: "mr-2 size-3.5"
                                }), c("users.auth_log.title")]
                            }), (0, r.jsx)(O.VD, {}), (0, r.jsxs)(O.Xi, {
                                onClick: () => l(!0),
                                disabled: "local" != t.auth_type,
                                children: [(0, r.jsx)(L.Z, {
                                    className: "mr-2 size-3.5"
                                }), c("delete")]
                            })]
                        })]
                    }), (0, r.jsx)(K, {
                        open: n,
                        setOpen: l,
                        user: t
                    })]
                })
            }

            function K(e) {
                let {
                    open: s,
                    setOpen: t,
                    user: n
                } = e, i = (0, f.q)(), {
                    toast: c
                } = (0, R.p)(), [o, d] = (0, a.useState)(!1), {
                    t: u
                } = (0, m.$G)("settings"), x = () => {
                    d(!0), l.dJ.delete("/settings/users/".concat(n.id)).then(() => {
                        c({
                            title: u("success"),
                            description: u("users.delete.success")
                        }), i.emit("REFETCH_USERS"), t(!1)
                    }).catch(() => {
                        c({
                            title: u("error"),
                            description: u("users.delete.error"),
                            variant: "destructive"
                        })
                    }).finally(() => {
                        d(!1)
                    })
                };
                return (0, r.jsx)(P.aR, {
                    open: s,
                    onOpenChange: e => t(e),
                    children: (0, r.jsxs)(P._T, {
                        children: [(0, r.jsxs)(P.fY, {
                            children: [(0, r.jsx)(P.f$, {
                                children: u("users.delete.title")
                            }), (0, r.jsx)(P.yT, {
                                children: (0, r.jsx)("span", {
                                    dangerouslySetInnerHTML: {
                                        __html: u("users.delete.subtext", {
                                            username: n.name
                                        })
                                    }
                                })
                            })]
                        }), (0, r.jsxs)(P.xo, {
                            children: [(0, r.jsx)(P.le, {
                                children: u("users.delete.no")
                            }), (0, r.jsxs)(P.OL, {
                                onClick: () => x(),
                                children: [o && (0, r.jsx)(W.P.spinner, {
                                    className: "size-4 animate-spin"
                                }), u("users.delete.yes")]
                            })]
                        })]
                    })
                })
            }
            let A = e => {
                switch (e) {
                    case "local":
                    default:
                        return "DZ";
                    case "keycloak":
                        return "Keycloak";
                    case "ldap":
                        return "LDAP"
                }
            };

            function H() {
                let [e, s] = (0, a.useState)(!0), [t, y] = (0, a.useState)([]), _ = (0, n.useRouter)(), N = (0, f.q)(), {
                    t: b,
                    i18n: w
                } = (0, m.$G)("settings"), k = [{
                    accessorKey: "name",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: b("users.name")
                        })
                    },
                    title: b("users.name")
                }, {
                    accessorKey: "username",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: b("users.username")
                        })
                    },
                    title: b("users.username")
                }, {
                    accessorKey: "email",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: b("users.email")
                        })
                    },
                    title: b("users.email")
                }, {
                    accessorKey: "status",
                    accessorFn: e => e.status ? "1" : "0",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: b("users.status"),
                            filterPresets: [{
                                key: b("users.admin"),
                                value: "1"
                            }, {
                                key: b("users.user"),
                                value: "0"
                            }]
                        })
                    },
                    title: b("users.status"),
                    cell: e => {
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(r.Fragment, {
                            children: 1 === s.original.status ? (0, r.jsxs)("div", {
                                className: "flex items-center",
                                children: [(0, r.jsx)(i, {
                                    className: "size-5"
                                }), (0, r.jsx)(h.C, {
                                    className: "ml-2",
                                    variant: "outline",
                                    children: b("users.admin")
                                })]
                            }) : (0, r.jsxs)("div", {
                                className: "flex items-center",
                                children: [(0, r.jsx)(c.Z, {
                                    className: "size-5"
                                }), (0, r.jsx)(h.C, {
                                    className: "ml-2",
                                    variant: "outline",
                                    children: b("users.user")
                                })]
                            })
                        })
                    }
                }, {
                    accessorKey: "last_login_at",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: b("users.last_login_at")
                        })
                    },
                    title: b("users.last_login_at"),
                    cell: e => {
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(r.Fragment, {
                            children: s.original.last_login_at ? (0, x.qF)(s.original.last_login_at, w.language) : b("users.never")
                        })
                    }
                }, {
                    accessorKey: "auth_type",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: b("users.auth_type"),
                            filterPresets: [{
                                key: "DZ",
                                value: "local"
                            }, {
                                key: "Keycloak",
                                value: "keycloak"
                            }, {
                                key: "LDAP",
                                value: "ldap"
                            }]
                        })
                    },
                    title: b("users.auth_type"),
                    cell: e => {
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(r.Fragment, {
                            children: A(s.original.auth_type)
                        })
                    }
                }, {
                    accessorKey: "otp_enabled",
                    accessorFn: e => e.otp_enabled ? 0 + b("users.otp_enabled") : b("users.otp_disabled"),
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: b("users.otp"),
                            filterPresets: [{
                                key: b("users.otp_enabled"),
                                value: 0 + b("users.otp_enabled")
                            }, {
                                key: b("users.otp_disabled"),
                                value: b("users.otp_disabled")
                            }]
                        })
                    },
                    title: b("users.otp"),
                    cell: e => {
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(r.Fragment, {
                            children: s.original.otp_enabled ? (0, r.jsxs)("div", {
                                className: "flex items-center",
                                children: [(0, r.jsx)(o.Z, {
                                    className: "size-5 text-green-500"
                                }), (0, r.jsx)(h.C, {
                                    className: "ml-2",
                                    variant: "success",
                                    children: b("users.otp_enabled")
                                })]
                            }) : (0, r.jsxs)("div", {
                                className: "flex items-center",
                                children: [(0, r.jsx)(d.Z, {
                                    className: "size-5 text-red-500"
                                }), (0, r.jsx)(h.C, {
                                    className: "ml-2",
                                    variant: "outline",
                                    children: b("users.otp_disabled")
                                })]
                            })
                        })
                    },
                    meta: {
                        hidden: !0
                    }
                }, {
                    id: "actions",
                    cell: e => {
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)("div", {
                            className: "flex justify-center",
                            children: (0, r.jsx)(q, {
                                row: s
                            })
                        })
                    }
                }], C = () => {
                    l.dJ.get("/settings/users").then(e => {
                        y(e.data), s(!1)
                    })
                };
                return (0, a.useEffect)(() => {
                    C()
                }, []), (0, a.useEffect)(() => (N.on("REFETCH_USERS", () => {
                    C()
                }), () => N.off("REFETCH_USERS")), []), (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(v.Z, {
                        title: b("users.title"),
                        description: b("users.description")
                    }), (0, r.jsx)(j.Z, {
                        columns: k,
                        data: t,
                        loading: e,
                        selectable: !1,
                        children: (0, r.jsxs)("div", {
                            className: "flex gap-3",
                            children: [(0, r.jsx)(S, {}), (0, r.jsx)(T, {}), (0, r.jsx)(U, {}), (0, r.jsxs)(p.z, {
                                variant: "outline",
                                size: "sm",
                                className: "ml-auto h-8 lg:flex",
                                onClick: () => _.push("/settings/users/logs"),
                                children: [(0, r.jsx)(u.Z, {
                                    className: "mr-2 size-4"
                                }), b("users.auth_log.title")]
                            })]
                        })
                    })]
                })
            }

            function U() {
                let [e, s] = (0, a.useState)(!1), [t, n] = (0, a.useState)(!0), [i, c] = (0, a.useState)([]), o = (0, f.q)(), {
                    t: d,
                    i18n: u
                } = (0, m.$G)("settings"), x = [{
                    accessorKey: "ip_address",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: d("users.auth_log.ip_address")
                        })
                    },
                    title: d("users.auth_log.ip_address")
                }, {
                    accessorKey: "user_agent",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: d("users.auth_log.browser")
                        })
                    },
                    title: d("users.auth_log.browser"),
                    cell: e => {
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(_.pn, {
                            delayDuration: 200,
                            children: (0, r.jsxs)(_.u, {
                                children: [(0, r.jsx)(_.aJ, {
                                    children: (0, r.jsx)("span", {
                                        className: "cursor-pointer text-blue-500",
                                        children: s.original.user_agent.substring(0, 30) + "..."
                                    })
                                }), (0, r.jsx)(_._v, {
                                    children: (0, r.jsx)("p", {
                                        children: s.original.user_agent
                                    })
                                })]
                            })
                        })
                    }
                }, {
                    accessorKey: "created_at",
                    header: e => {
                        let {
                            column: s
                        } = e;
                        return (0, r.jsx)(g.p, {
                            column: s,
                            title: d("users.auth_log.created_at")
                        })
                    },
                    title: d("users.auth_log.created_at"),
                    accessorFn: e => new Date(e.created_at).toLocaleDateString(u.language, {
                        day: "2-digit",
                        month: "long",
                        year: "numeric",
                        hour: "2-digit",
                        minute: "2-digit"
                    }),
                    cell: e => {
                        let {
                            row: s
                        } = e;
                        return (0, r.jsx)(r.Fragment, {
                            children: s.original.created_at ? new Date(s.original.created_at).toLocaleDateString(u.language, {
                                day: "2-digit",
                                month: "long",
                                year: "numeric",
                                hour: "2-digit",
                                minute: "2-digit"
                            }) : d("users.auth_log.unknown")
                        })
                    }
                }];
                return o.on("AUTH_LOG_DIALOG", e => {
                    n(!0), s(!0), l.dJ.get("/settings/users/auth_logs/".concat(e)).then(e => {
                        c(e.data), n(!1)
                    })
                }), (0, r.jsx)(y.Vq, {
                    open: e,
                    onOpenChange: s,
                    children: (0, r.jsx)(y.cZ, {
                        className: "max-w-[75vw] p-0",
                        children: (0, r.jsxs)("div", {
                            className: "grid grid-cols-4",
                            children: [(0, r.jsxs)("div", {
                                className: "rounded-lg rounded-r-none bg-foreground/5 p-5",
                                children: [(0, r.jsx)("h3", {
                                    className: "font-semibold",
                                    children: d("users.auth_log.title")
                                }), (0, r.jsx)("p", {
                                    className: "mt-5 text-sm text-muted-foreground",
                                    children: d("users.auth_log.desc2")
                                })]
                            }), (0, r.jsx)("div", {
                                className: "col-span-3 py-5",
                                children: (0, r.jsx)(j.Z, {
                                    columns: x,
                                    data: i,
                                    loading: t,
                                    selectable: !1
                                })
                            })]
                        })
                    })
                })
            }
        },
        6069: function(e, s, t) {
            "use strict";
            t.d(s, {
                fC: function() {
                    return b
                },
                z$: function() {
                    return w
                }
            });
            var r = t(7462),
                a = t(7294),
                n = t(8771),
                l = t(5360),
                i = t(6206),
                c = t(7342),
                o = t(7898),
                d = t(7546),
                u = t(9115),
                m = t(5320);
            let x = "Checkbox",
                [f, h] = (0, l.b)(x),
                [p, j] = f(x),
                g = (0, a.forwardRef)((e, s) => {
                    let {
                        __scopeCheckbox: t,
                        name: l,
                        checked: o,
                        defaultChecked: d,
                        required: u,
                        disabled: x,
                        value: f = "on",
                        onCheckedChange: h,
                        ...j
                    } = e, [g, y] = (0, a.useState)(null), b = (0, n.e)(s, e => y(e)), w = (0, a.useRef)(!1), k = !g || !!g.closest("form"), [C = !1, z] = (0, c.T)({
                        prop: o,
                        defaultProp: d,
                        onChange: h
                    }), F = (0, a.useRef)(C);
                    return (0, a.useEffect)(() => {
                        let e = null == g ? void 0 : g.form;
                        if (e) {
                            let s = () => z(F.current);
                            return e.addEventListener("reset", s), () => e.removeEventListener("reset", s)
                        }
                    }, [g, z]), (0, a.createElement)(p, {
                        scope: t,
                        state: C,
                        disabled: x
                    }, (0, a.createElement)(m.WV.button, (0, r.Z)({
                        type: "button",
                        role: "checkbox",
                        "aria-checked": _(C) ? "mixed" : C,
                        "aria-required": u,
                        "data-state": N(C),
                        "data-disabled": x ? "" : void 0,
                        disabled: x,
                        value: f
                    }, j, {
                        ref: b,
                        onKeyDown: (0, i.M)(e.onKeyDown, e => {
                            "Enter" === e.key && e.preventDefault()
                        }),
                        onClick: (0, i.M)(e.onClick, e => {
                            z(e => !!_(e) || !e), k && (w.current = e.isPropagationStopped(), w.current || e.stopPropagation())
                        })
                    })), k && (0, a.createElement)(v, {
                        control: g,
                        bubbles: !w.current,
                        name: l,
                        value: f,
                        checked: C,
                        required: u,
                        disabled: x,
                        style: {
                            transform: "translateX(-100%)"
                        }
                    }))
                }),
                y = (0, a.forwardRef)((e, s) => {
                    let {
                        __scopeCheckbox: t,
                        forceMount: n,
                        ...l
                    } = e, i = j("CheckboxIndicator", t);
                    return (0, a.createElement)(u.z, {
                        present: n || _(i.state) || !0 === i.state
                    }, (0, a.createElement)(m.WV.span, (0, r.Z)({
                        "data-state": N(i.state),
                        "data-disabled": i.disabled ? "" : void 0
                    }, l, {
                        ref: s,
                        style: {
                            pointerEvents: "none",
                            ...e.style
                        }
                    })))
                }),
                v = e => {
                    let {
                        control: s,
                        checked: t,
                        bubbles: n = !0,
                        ...l
                    } = e, i = (0, a.useRef)(null), c = (0, o.D)(t), u = (0, d.t)(s);
                    return (0, a.useEffect)(() => {
                        let e = i.current,
                            s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "checked").set;
                        if (c !== t && s) {
                            let r = new Event("click", {
                                bubbles: n
                            });
                            e.indeterminate = _(t), s.call(e, !_(t) && t), e.dispatchEvent(r)
                        }
                    }, [c, t, n]), (0, a.createElement)("input", (0, r.Z)({
                        type: "checkbox",
                        "aria-hidden": !0,
                        defaultChecked: !_(t) && t
                    }, l, {
                        tabIndex: -1,
                        ref: i,
                        style: {
                            ...e.style,
                            ...u,
                            position: "absolute",
                            pointerEvents: "none",
                            opacity: 0,
                            margin: 0
                        }
                    }))
                };

            function _(e) {
                return "indeterminate" === e
            }

            function N(e) {
                return _(e) ? "indeterminate" : e ? "checked" : "unchecked"
            }
            let b = g,
                w = y
        },
        9391: function(e, s, t) {
            "use strict";

            function r(e) {
                return {
                    all: e = e || new Map,
                    on: function(s, t) {
                        var r = e.get(s);
                        r ? r.push(t) : e.set(s, [t])
                    },
                    off: function(s, t) {
                        var r = e.get(s);
                        r && (t ? r.splice(r.indexOf(t) >>> 0, 1) : e.set(s, []))
                    },
                    emit: function(s, t) {
                        var r = e.get(s);
                        r && r.slice().map(function(e) {
                            e(t)
                        }), (r = e.get("*")) && r.slice().map(function(e) {
                            e(s, t)
                        })
                    }
                }
            }
            t.d(s, {
                Z: function() {
                    return r
                }
            })
        }
    },
    function(e) {
        e.O(0, [5059, 3265, 3051, 5855, 2888, 9774, 179], function() {
            return e(e.s = 7391)
        }), _N_E = e.O()
    }
]);